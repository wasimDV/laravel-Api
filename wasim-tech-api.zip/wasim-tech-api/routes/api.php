<?php

use Illuminate\Http\Request;

/*
  |--------------------------------------------------------------------------
  | API Routes
  |--------------------------------------------------------------------------
  |
  | Here is where you can register API routes for your application. These
  | routes are loaded by the RouteServiceProvider within a group which
  | is assigned the "api" middleware group. Enjoy building your API!
  |
 */

//header('Access-Control-Allow-Origin: *');
//header("Access-Control-Allow-Origin: http://localhost");
//header('Access-Control-Allow-Origin: *');
////header('allow-origin: *');
//header('Access-Control-Allow-Methods:  POST, GET, OPTIONS, PUT, DELETE');
//header('Access-Control-Allow-Headers:  Content-Type, X-Auth-Token, Origin, Authorization');

//header('Access-Control-Allow-Origin', '*');
//header('Access-Control-Allow-Methods', '*');
//header('Access-Control-Allow-Headers', '*');

Route::middleware('auth:api')->get('/user', function (Request $request) {
  return $request->user();
});

Route::group(['middleware' => 'cors', 'prefix' => '/v1'], function () {
  Route::post('/login', 'UserController@authenticate');
  Route::post('/register', 'UserController@register');
  Route::get('/logout/{api_token}', 'UserController@logout');  
});

Route::group(['middleware' => ['cors', 'jwt.verify'], 'prefix' => '/v1'], function() {
  Route::get('/user', 'UserController@getAuthenticatedUser');
  Route::get('/details', 'UserController@details');
  Route::get('/employees', 'EmployeeController@employeeList');
  Route::post('/employees', 'EmployeeController@employeeUpdate');
  Route::put('/employees', 'EmployeeController@employeeUpdate');
  Route::get('/users', 'UserController@userList');
});
