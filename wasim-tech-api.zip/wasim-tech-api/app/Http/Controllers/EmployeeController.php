<?php

namespace App\Http\Controllers;

use App\User;
use Illuminate\Http\Request;
use App\Http\Requests;
use JWTAuth;
use Response;
use App\Repository\Transformers\UserTransformer;
use \Illuminate\Http\Response as Res;
use Validator;
use Tymon\JWTAuth\Exceptions\JWTException;
use Illuminate\Support\Facades\DB;
use App\Helpers\Helper;

class EmployeeController extends ApiController {

  public function __construct() {
    
  }

  public function employeeList() {
    try {
      $employees = DB::table('v_employees_master')->paginate(20);
      $this->setStatusCode(Res::HTTP_OK);
      return $this->respond([
          'status' => TRUE,
          'status_code' => $this->getStatusCode(),
          'resp' => $employees,
      ]);
    } catch (\Exception $e) {
      return $this->respondInternalError("An error occurred while performing an action!");
    }
  }

  public function employeeUpdate(Request $request) {
    $rules = array(
      'name' => 'required|max:255',
      'emp_code' => 'required|max:255',
      'mobile' => 'required|min:10',
      'email' => 'required|max:255|unique:fliplearn_employees',
      'designation' => 'required|exists:designations,id',
      'department' => 'required|exists:department,id',
      'reporting_manager' => 'required|exists:fliplearn_employees,id',
      'joining_date' => 'nullable',
      'resignation_date' => 'nullable',
      'gender' => 'nullable',
      'flip_status' => 'required'
    );
    $validator = Validator::make($request->all(), $rules);
    if ($validator->fails()) {
      return $this->respondValidationError('Fields Validation Failed.', $validator->errors());
    } else {
        $record = $this->prepareRequest($request);
        if(empty($request['id'])) {
          DB::table('fliplearn_employees')->insert($record);
        } else {
          DB::table('fliplearn_employees')->where('id', $request['id'])->update($record);
        }
      return $this->_login($request['email'], $request['password']);
    }
  }
  
  private function prepareRequest($request) {
    return [
          'name' => $request['name'],
          'emp_code' => $request['emp_code'],
          'gender' => $request['gender'],
          'mobile' => $request['mobile'],
          'designation' => $request['designation'],
          'department' => $request['department'],
          'reporting_manager' => $request['reporting_manager'],
          'joining_date' => $request['joining_date'],
          'resignation_date' => $request['resignation_date'],
          'flip_status' => $request['flip_status'],
          'created_at' => currentTime(),
          'updated_at' => currentTime(),
      ];
  }

}
