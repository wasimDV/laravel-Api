<?php

if (!function_exists('p')) {
    function p($value)
    {
      print_r($value);
      die();
    }
}

if (!function_exists('currentTime')) {
    function currentTime()
    {
      return date('Y-m-d H:i:s');
    }
}
